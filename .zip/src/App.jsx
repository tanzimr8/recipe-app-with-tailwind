// Pages
    //**************
    // Home
    // Favorites
    // Details
    // *************
    // Components
    // *************
    // Home
    // Nav
    // Recipes
    // Recipe
    // Contexts
    // Favorites
    // Favorite
    // Details
    // Routes
import './index.css';
import Nav from './components/shared/Nav';
import Search from './components/shared/Search';
import Home from './components/pages/Home';
import {Routes, Route} from 'react-router-dom'
function App() {
  return (
    <>
      <Nav/>
      <Search/>
      <Routes>
        <Route path='/' element={<Home/>} />
      </Routes>
    </>
    
  );
}

export default App;
